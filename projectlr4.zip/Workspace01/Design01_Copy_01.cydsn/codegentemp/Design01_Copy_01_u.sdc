# Component constraints for C:\Users\STUDENT\Documents\PSoC Creator\Workspace01\Design01_Copy_01.cydsn\TopDesign\TopDesign.cysch
# Project: C:\Users\STUDENT\Documents\PSoC Creator\Workspace01\Design01_Copy_01.cydsn\Design01_Copy_01.cyprj
# Date: Mon, 20 Apr 2026 07:51:27 GMT
