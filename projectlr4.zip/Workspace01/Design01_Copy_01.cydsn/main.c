#include "project.h"
#include <stdlib.h>
#include <time.h>

int main(void)
{
    CyGlobalIntEnable; /* Enable global interrupts. */

    /* Place your initialization/startup code here (e.g. MyInst_Start()) */

    for(;;)
    {
        if(Button_Read() == 0)
        {
            LED_R_Write(rand() % 2);
            LED_G_Write(rand() % 2);
            LED_B_Write(rand() % 2);
            
            CyDelay(100);
        }
    }
}
