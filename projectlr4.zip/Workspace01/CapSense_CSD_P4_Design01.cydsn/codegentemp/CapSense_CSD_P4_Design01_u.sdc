# Component constraints for C:\Users\STUDENT\Documents\PSoC Creator\Workspace01\CapSense_CSD_P4_Design01.cydsn\TopDesign\TopDesign.cysch
# Project: C:\Users\STUDENT\Documents\PSoC Creator\Workspace01\CapSense_CSD_P4_Design01.cydsn\CapSense_CSD_P4_Design01.cyprj
# Date: Mon, 16 Feb 2026 09:00:55 GMT
