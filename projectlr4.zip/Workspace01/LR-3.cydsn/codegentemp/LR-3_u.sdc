# Component constraints for C:\Users\STUDENT\Documents\PSoC Creator\Workspace01\LR-3.cydsn\TopDesign\TopDesign.cysch
# Project: C:\Users\STUDENT\Documents\PSoC Creator\Workspace01\LR-3.cydsn\LR-3.cyprj
# Date: Mon, 20 Apr 2026 08:31:43 GMT
