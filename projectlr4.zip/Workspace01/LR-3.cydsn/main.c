#include "project.h"

#define ROWS 4
#define COLS 3

// 7-segment patterns (common anode)
static const uint8_t LED_NUM[] = {
    0x98, // [0]  0
    0xAB, // [1]  1
    0xF9, // [2]  2
    0x90, // [3]  3
    0x86, // [4]  4
    0xAF, // [5]  5
    0x92, // [6]  6
    0xF8, // [7]  7
    0x80, // [8]  8
    0x91, // [9]  9
    0xBF, // [10] -
    0x88, // [11] A
    0x83, // [12] b
    0xC6, // [13] C
    0xA1, // [14] d
    0x86, // [15] E
    0x8E  // [16] F
};

static const char* const SYM_NAME[] = {
    "0","1","2","3","4","5","6","7","8","9",
    "-","A","b","C","d","E","F"
};

// Mode 0 — числа: кожна клавіша дає свою цифру
// 0xFF = службова (перемикач режиму, без виводу)
static const uint8_t num_map[ROWS][COLS] = {
    { 1,  2,  3}, // 1, 2, 3
    { 4,  5,  6}, // 4, 5, 6
    { 7,  8,  9}, // 7, 8, 9
    {0xFF, 0, 10} // *(toggle), 0, -
};

// Mode 1 — літери: A b C d E F; решта — ті самі цифри
static const uint8_t let_map[ROWS][COLS] = {
    {15, 16, 11}, // E, F, A
    { 4,  5, 12}, // 4, 5, b
    { 7,  8, 13}, // 7, 8, C
    {0xFF, 0, 14} // *(toggle), 0, d
};

static uint8_t keys[ROWS][COLS];
static uint8_t last_keys[ROWS][COLS];
static uint8_t mode       = 0;  // 0=числа, 1=літери
static uint8_t last_sym   = 10; // поточний символ на дисплеї

// ── 74HC595 ───────────────────────────────────────────────────────────────────

static void HC595_sendByte(uint8_t data) {
    for (uint8_t i = 0; i < 8; i++) {
        Pin_DO_Write((data & (0x80 >> i)) ? 1 : 0);
        Pin_CLK_Write(1);
        Pin_CLK_Write(0);
    }
}

// dot=1 → крапка горить (індикатор літерного режиму)
static void display_show(uint8_t sym_idx, uint8_t dot) {
    if (sym_idx >= 17) return;
    HC595_sendByte(0xFF & ~(1u << 0)); // позиція 0
    uint8_t pattern = LED_NUM[sym_idx];
    if (dot) pattern &= 0x7F;
    HC595_sendByte(pattern);
    Pin_Latch_Write(1);
    Pin_Latch_Write(0);
}

// ── Pin wrappers ──────────────────────────────────────────────────────────────

static void col_drive(uint8_t col, uint8_t m) {
    switch (col) {
        case 0: COLUMN_0_SetDriveMode(m); break;
        case 1: COLUMN_1_SetDriveMode(m); break;
        case 2: COLUMN_2_SetDriveMode(m); break;
    }
}

static void col_write(uint8_t col, uint8_t val) {
    switch (col) {
        case 0: COLUMN_0_Write(val); break;
        case 1: COLUMN_1_Write(val); break;
        case 2: COLUMN_2_Write(val); break;
    }
}

static uint8_t row_read(uint8_t row) {
    switch (row) {
        case 0: return ROW_0_Read();
        case 1: return ROW_1_Read();
        case 2: return ROW_2_Read();
        case 3: return ROW_3_Read();
        default: return 1;
    }
}

static void rgb_set(uint8_t r, uint8_t g, uint8_t b) {
    LED_R_Write(r);
    LED_G_Write(g);
    LED_B_Write(b);
}

// ── Matrix ────────────────────────────────────────────────────────────────────

static void matrix_init(void) {
    for (int c = 0; c < COLS; c++)
        col_drive(c, COLUMN_0_DM_DIG_HIZ);
    for (int r = 0; r < ROWS; r++)
        for (int c = 0; c < COLS; c++)
            last_keys[r][c] = 1;
}

static void matrix_read(void) {
    for (int c = 0; c < COLS; c++) {
        col_drive(c, COLUMN_0_DM_STRONG);
        col_write(c, 0);
        for (int r = 0; r < ROWS; r++)
            keys[r][c] = row_read(r);
        col_write(c, 1);
        col_drive(c, COLUMN_0_DM_DIG_HIZ);
    }
}

// ── Main ──────────────────────────────────────────────────────────────────────

int main(void) {
    CyGlobalIntEnable;
    SW_Tx_UART_Start();
    matrix_init();

    display_show(last_sym, mode); // '-' без крапки
    rgb_set(1, 1, 1);             // всі LED вимкнені

    SW_Tx_UART_PutString("=== Ready ===\r\n");
    SW_Tx_UART_PutString("[*] = toggle mode  |  MODE 0: digits  |  MODE 1: letters\r\n\r\n");

    for (;;) {
        matrix_read();

        for (int r = 0; r < ROWS; r++) {
            for (int c = 0; c < COLS; c++) {

                // ── Натискання ────────────────────────────────────────────
                if (keys[r][c] == 0 && last_keys[r][c] == 1) {

                    if (r == 3 && c == 0) {
                        // ── Перемикач режиму ──────────────────────────────
                        mode ^= 1;

                        // Оновити дисплей: крапка = літерний режим
                        display_show(last_sym, mode);

                        // RGB: синій = літери, вимкнений = числа
                        rgb_set(1, 1, mode ? 0 : 1);

                        SW_Tx_UART_PutString(">> MODE: ");
                        SW_Tx_UART_PutString(mode ? "LETTERS (A b C d E F)\r\n"
                                                   : "DIGITS  (0-9)\r\n");

                    } else {
                        // ── Звичайна клавіша ──────────────────────────────
                        uint8_t val = mode ? let_map[r][c] : num_map[r][c];

                        last_sym = val;
                        display_show(val, mode); // крапка = поточний режим

                        SW_Tx_UART_PutString("Key: ");
                        SW_Tx_UART_PutString(SYM_NAME[val]);
                        SW_Tx_UART_PutString(mode ? "  [LETTER]\r\n" : "  [DIGIT]\r\n");

                        rgb_set(0, 0, 0); // білий спалах при натисканні
                    }
                }

                // ── Відпускання ───────────────────────────────────────────
                if (keys[r][c] == 1 && last_keys[r][c] == 0) {
                    // Відновити RGB-індикатор режиму
                    rgb_set(1, 1, mode ? 0 : 1);
                }

                last_keys[r][c] = keys[r][c];
            }
        }

        CyDelay(25);
    }
}